import Foundation

struct Avatar : Codable {
    let gravatar: Gravatar?
    let tmdb: Tmdb?
}
