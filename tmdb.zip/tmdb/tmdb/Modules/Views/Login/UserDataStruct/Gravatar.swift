import Foundation

struct Gravatar : Codable {
    let hash: String
}
