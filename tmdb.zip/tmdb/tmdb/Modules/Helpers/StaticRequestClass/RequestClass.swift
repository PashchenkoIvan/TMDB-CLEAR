//
//  RequestClass.swift
//  tmdb
//
//  Created by Пащенко Иван on 28.05.2024.
//

import Foundation

